Predict
==========
Used to make predictions


.. autoclass:: predict.predict
   :members:
   :undoc-members:

    
