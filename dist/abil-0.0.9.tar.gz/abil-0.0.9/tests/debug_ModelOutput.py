#%%
import pandas as pd
from yaml import load
from yaml import CLoader as Loader
from sklearn.preprocessing import OneHotEncoder

import os, sys
os.chdir('/home/mv23682/Documents/Abil_output_branch/Abil/')  # Provide your path here

sys.path.insert(0, './abil/')
from abil.tune import tune
from abil.functions import upsample
# %%
# Setting up a regressor model
with open('./tests/classifier.yml', 'r') as f:
    model_config = load(f, Loader=Loader)

model_config['local_root'] = os.getenv('','.') # set local directory

predictors = model_config['predictors']
#read your target + environmental data:
d = pd.read_csv(model_config['local_root'] + model_config['training'])
target =  "Emiliania huxleyi"


#in this example we introduce pseudo-absences:
d[target] = d[target].fillna(0)
d = upsample(d, target, ratio=10)


#drop any missing values:
d = d.dropna(subset=[target])
d = d.dropna(subset=predictors)

#here we randomly sample data to speed up training:
d = d.sample(1000)

X_train = d[predictors]
y = d[target]

m = tune(X_train, y, model_config)
# %% Train
'''
1-phase RF classifier
'''
m.train(model="rf", classifier=True)
'''
1-phase RF regressor
'''
#m.train(model="rf", regressor=True)
'''
2-phase RF regressor
'''
#m.train(model="rf", classifier=True, regressor=True)
'''
1-phase KNN classifier
'''
m.train(model="knn", classifier=True)
'''
1-phase KNN regressor
'''
#m.train(model="knn", regressor=True)
'''
2-phase KNN regressor
'''
#m.train(model="knn", classifier=True, regressor=True)
'''
1-phase XGB classifier
'''
m.train(model="xgb", classifier=True)
'''
1-phase XGB regressor
'''
#m.train(model="xgb", regressor=True)
'''
2-phase XGB regressor
'''
#m.train(model="xgb", classifier=True, regressor=True)
# %% Predict
from abil.predict import predict
predictors = model_config['predictors']
d = pd.read_csv("./examples/data/training.csv")
species = 'Emiliania huxleyi'
d = d[d[species]>0]

d.dropna(subset=predictors, inplace=True)
d.dropna(subset=species, inplace=True)

X_train = d[predictors]
y = d[species]
X_predict = pd.read_csv("./examples/data/prediction.csv")
X_predict.set_index(["time", "depth", "lat", "lon"], inplace=True)

X_predict = X_predict[X_train.columns]

m = predict(X_train=X_train, y=y, X_predict=X_predict, 
    model_config=model_config, n_jobs=2)
m.make_prediction(prediction_inference=False)
# %%
from abil.post import post
from datetime import datetime
current_date = datetime.today().strftime('%Y-%m-%d')
root = model_config['local_root']
print("path:")
print(root + model_config['targets'])
targets = pd.read_csv(root + model_config['targets'])
targets =  targets['Target'].values
depth_w = 5
conversion = 1e3 #L-1 to m-3
X_predict = pd.read_csv("./examples/data/prediction.csv")
X_predict.set_index(["time", "depth", "lat", "lon"], inplace=True)

X_predict = X_predict[X_train.columns]

# %%
def do_post(pi):
    m = post(model_config, pi=pi)
    m.merge_performance(model="ens") 
    m.merge_performance(model="xgb")
    m.merge_performance(model="rf")
    m.merge_performance(model="knn")

    m.merge_parameters(model="rf")
    m.merge_parameters(model="xgb")
    m.merge_parameters(model="knn")

    m.total()

    m.merge_env(X_predict)

    m.export_ds("test")
    m.export_csv("test")

    targets = ['Emiliania huxleyi','total']
    vol_conversion = 1e3 #L-1 to m-3
    integ = m.integration(m, vol_conversion=vol_conversion)
    integ.integrated_totals(targets)
    integ.integrated_totals(targets, subset_depth=100)

do_post(pi="50")
do_post(pi="95_UL")
do_post(pi="95_LL")
#%%
